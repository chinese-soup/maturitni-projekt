# /static/ references, sources and resources
* [http://getbootstrap.com/](http://getbootstrap.com/)
* [http://www.himpfen.com/bootstrap-jumbotron-background-cover-image/](http://www.himpfen.com/bootstrap-jumbotron-background-cover-image/)
* [https://realfavicongenerator.net](https://realfavicongenerator.net/)
* [http://www.cssmatic.com/box-shadow](http://www.cssmatic.com/box-shadow)
* [http://www.webhostinghub.com/glyphs/](http://www.webhostinghub.com/glyphs/)