# Web-client/static
Templaty klientské části aplikace
